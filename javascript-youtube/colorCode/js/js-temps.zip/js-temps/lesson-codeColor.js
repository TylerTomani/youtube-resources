const stepTxts = document.querySelectorAll('.step-txt')

stepTxts.forEach(el => {    
    
})